import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class PalDatabase {
  PalDatabase._();
  static final PalDatabase instance = PalDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    _db = await openDatabase(
      join(dir, 'paldy_payment_all.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, description TEXT, customer TEXT, amount INTEGER, paid INTEGER, change_amount INTEGER, created_at TEXT)');
      },
    );
    return _db!;
  }

  Future<int> add(Map<String, Object?> row) async =>
      (await database).insert('transactions', row);

  Future<List<Map<String, Object?>>> all() async =>
      (await database).query('transactions', orderBy: 'id DESC');
}
