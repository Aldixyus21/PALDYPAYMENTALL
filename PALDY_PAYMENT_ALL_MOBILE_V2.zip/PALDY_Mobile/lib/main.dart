import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'database.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PalDatabase.instance.database;
  runApp(const PaldyApp());
}

final fmt = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

class PaldyApp extends StatelessWidget {
  const PaldyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'PALDY - PAYMENT ALL',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087BFF)), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  List<Map<String, Object?>> rows = [];
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    final r = await PalDatabase.instance.all();
    if (mounted) setState(() => rows = r);
  }

  int get income => rows.where((r) => r['kind'] != 'PENGELUARAN').fold(0, (s, r) => s + (r['amount'] as int));
  int get expense => rows.where((r) => r['kind'] == 'PENGELUARAN').fold(0, (s, r) => s + (r['amount'] as int));

  @override
  Widget build(BuildContext context) {
    final pages = [dashboard(), history(), reports()];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF071A35),
        foregroundColor: Colors.white,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('PALDY', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
          Text('PAYMENT ALL • V2.0', style: TextStyle(fontSize: 11)),
        ]),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      body: pages[tab],
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(
        onPressed: newTransaction, icon: const Icon(Icons.add), label: const Text('Transaksi baru'),
      ) : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Riwayat'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Laporan'),
        ],
      ),
    );
  }

  Widget dashboard() => RefreshIndicator(
    onRefresh: load,
    child: ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF071A35), Color(0xFF087BFF)]),
          borderRadius: BorderRadius.circular(22),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('SELAMAT DATANG DI', style: TextStyle(color: Colors.white70)),
          Text('PALDY', style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: 3)),
          Text('PAYMENT ALL', style: TextStyle(color: Colors.white, fontSize: 17, letterSpacing: 2)),
          SizedBox(height: 8),
          Text('Kelola transaksi harian dengan mudah.', style: TextStyle(color: Colors.white70)),
        ]),
      ),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: card('Pemasukan', income, Colors.green, Icons.trending_up)),
        const SizedBox(width: 10),
        Expanded(child: card('Pengeluaran', expense, Colors.red, Icons.trending_down)),
      ]),
      const SizedBox(height: 10),
      card('Saldo bersih', income - expense, Colors.blue, Icons.account_balance_wallet),
      const SizedBox(height: 20),
      const Text('Transaksi terbaru', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...rows.take(5).map(tile),
      if (rows.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('Belum ada transaksi. Tekan Transaksi baru untuk memulai.')),
      const SizedBox(height: 80),
    ]),
  );

  Widget card(String title, int amount, Color color, IconData icon) => Card(
    elevation: 0,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        CircleAvatar(backgroundColor: color.withOpacity(.12), child: Icon(icon, color: color)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.black54)),
          Text(fmt.format(amount), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        ])),
      ]),
    ),
  );

  Widget tile(Map<String, Object?> r) {
    final out = r['kind'] == 'PENGELUARAN';
    return Card(
      elevation: 0,
      child: ListTile(
        leading: CircleAvatar(child: Icon(out ? Icons.south_west : Icons.north_east)),
        title: Text(r['description'] as String),
        subtitle: Text('${r['kind']} • ${r['customer']}'),
        trailing: Text('${out ? '-' : '+'}${fmt.format(r['amount'])}',
          style: TextStyle(color: out ? Colors.red : Colors.green, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget history() => rows.isEmpty
    ? const Center(child: Text('Belum ada riwayat transaksi.'))
    : ListView(padding: const EdgeInsets.all(16), children: rows.map(tile).toList());

  Widget reports() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Ringkasan keuangan', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    card('Total pemasukan', income, Colors.green, Icons.trending_up),
    card('Total pengeluaran', expense, Colors.red, Icons.trending_down),
    card('Saldo bersih', income - expense, Colors.blue, Icons.account_balance),
    Padding(padding: const EdgeInsets.all(8), child: Text('Jumlah transaksi: ${rows.length}')),
    const Text('Rekap ini mencakup seluruh data yang tersimpan, belum difilter per hari atau bulan.'),
  ]);

  Future<void> newTransaction() async {
    final ok = await showModalBottomSheet<bool>(
      context: context, isScrollControlled: true,
      builder: (_) => const TransactionForm(),
    );
    if (ok == true) load();
  }
}

class TransactionForm extends StatefulWidget {
  const TransactionForm({super.key});
  @override
  State<TransactionForm> createState() => _TransactionFormState();
}

class _TransactionFormState extends State<TransactionForm> {
  final form = GlobalKey<FormState>();
  final desc = TextEditingController();
  final customer = TextEditingController();
  final amount = TextEditingController();
  final paid = TextEditingController();
  String kind = 'PEMBAYARAN';
  bool saving = false;

  @override
  void dispose() { desc.dispose(); customer.dispose(); amount.dispose(); paid.dispose(); super.dispose(); }

  Future<void> save() async {
    if (!form.currentState!.validate()) return;
    final a = int.parse(amount.text);
    final p = kind == 'PENGELUARAN' ? a : int.parse(paid.text);
    if (p < a) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Uang diterima kurang dari nominal.')));
      return;
    }
    setState(() => saving = true);
    await PalDatabase.instance.add({
      'kind': kind, 'description': desc.text.trim(),
      'customer': customer.text.trim().isEmpty ? '-' : customer.text.trim(),
      'amount': a, 'paid': p, 'change_amount': p - a,
      'created_at': DateTime.now().toIso8601String(),
    });
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.fromLTRB(18, 18, 18, MediaQuery.of(context).viewInsets.bottom + 18),
    child: SingleChildScrollView(child: Form(
      key: form,
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Transaksi baru', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: kind, decoration: const InputDecoration(labelText: 'Jenis transaksi', border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'PEMBAYARAN', child: Text('Pembayaran')),
            DropdownMenuItem(value: 'PENJUALAN', child: Text('Penjualan / Kasir')),
            DropdownMenuItem(value: 'PEMASUKAN', child: Text('Pemasukan')),
            DropdownMenuItem(value: 'PENGELUARAN', child: Text('Pengeluaran')),
          ],
          onChanged: (v) => setState(() => kind = v!),
        ),
        const SizedBox(height: 10),
        TextFormField(controller: desc, decoration: const InputDecoration(labelText: 'Keterangan transaksi', border: OutlineInputBorder()),
          validator: (v) => v == null || v.trim().isEmpty ? 'Wajib diisi' : null),
        const SizedBox(height: 10),
        TextFormField(controller: customer, decoration: const InputDecoration(labelText: 'Nama pelanggan / pihak (opsional)', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextFormField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Nominal (Rp)', border: OutlineInputBorder()),
          validator: (v) => (int.tryParse(v ?? '') ?? 0) <= 0 ? 'Masukkan nominal lebih dari 0' : null),
        if (kind != 'PENGELUARAN') ...[
          const SizedBox(height: 10),
          TextFormField(controller: paid, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Uang diterima (Rp)', border: OutlineInputBorder()),
            validator: (v) => (int.tryParse(v ?? '') ?? 0) <= 0 ? 'Masukkan uang diterima' : null),
        ],
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.save), label: Text(saving ? 'Menyimpan...' : 'Simpan transaksi')),
      ]),
    )),
  );
}
