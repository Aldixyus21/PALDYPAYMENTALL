PALDY - PAYMENT ALL V2.0 MOBILE
Source project Flutter untuk Android dan iOS.

Fitur starter:
- Dashboard pemasukan, pengeluaran, saldo bersih
- Transaksi pembayaran, penjualan/kasir, pemasukan, pengeluaran
- Hitung kembalian
- Riwayat transaksi
- Ringkasan laporan seluruh data
- Database lokal SQLite di perangkat

CARA MENJALANKAN
1. Instal Flutter SDK: https://docs.flutter.dev/get-started/install
2. Ekstrak folder PALDY_Mobile.
3. Buka terminal pada folder proyek dan jalankan: flutter pub get
4. Android: jalankan flutter run, atau buat APK dengan:
   flutter build apk --release
5. iOS: perlu komputer macOS dan Xcode, lalu jalankan:
   flutter build ios --release

CATATAN PENTING
- Paket ini adalah SOURCE PROJECT, bukan APK atau IPA siap instal.
- Untuk build iOS wajib macOS + Xcode dan proses signing Apple.
- Database masih lokal di perangkat; belum ada sinkronisasi cloud/multi-device.
- Belum memproses QRIS, transfer bank, atau e-wallet secara langsung.
- Rekap laporan saat ini adalah seluruh data, belum filter harian/bulanan.
- Uji dan backup data sebelum digunakan untuk operasional usaha.

Identitas: PALDY - PAYMENT ALL | Versi 2.0
Developer: Aldy Remix4Life
